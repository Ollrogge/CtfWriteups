#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

int main () {
    setuid(0);
    setgid(0);

    system("/sbin/setcap cap_net_raw=ep /home/ctf/exploit");

   return(0);
} 