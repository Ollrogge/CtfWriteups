#!/bin/bash


(while true; do 
    /home/ctf/libiec61850/build/examples/goose_subscriber/goose_subscriber_example lo
done) &

dropbear -FBREkwp 1024